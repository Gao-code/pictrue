---
title: 关于
date: 2024-12-22 10:02:41
---

# **零·关于本站**

## 0.技术支持

本站搭载与Github

使用Vercel进行静态部署

域名使用Cloudflare托管

## 1.启蒙导师

[Fomalhaut🥝](https://www.fomal.cc/)

[butterfly](https://butterfly.js.org/)

## 2.本站的地理位置

![本站的地理位置](https://picture.invincible.us.kg/img/website/about1.png)

# 壹·关于作者

## 一个畜中牲
